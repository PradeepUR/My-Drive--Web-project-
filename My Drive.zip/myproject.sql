-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2019 at 05:50 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`email`),
  UNIQUE KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `fname`, `lname`, `dob`, `email`, `password`) VALUES
(2, '123', '456', '2019-11-01', '123@gmail.com', '123'),
(1, 'abc', 'def', '2019-11-01', 'abc@gmail.com', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `audios`
--

CREATE TABLE IF NOT EXISTS `audios` (
  `tag` varchar(20) NOT NULL,
  `audio_name` varchar(50) NOT NULL,
  `audio_id` int(11) NOT NULL AUTO_INCREMENT,
  `audio_location` varchar(200) NOT NULL,
  `user_id` int(3) NOT NULL,
  `audio_size` int(50) NOT NULL,
  PRIMARY KEY (`audio_id`),
  UNIQUE KEY `audio_id` (`audio_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `audios`
--

INSERT INTO `audios` (`tag`, `audio_name`, `audio_id`, `audio_location`, `user_id`, `audio_size`) VALUES
('sarigama', '1575394380Sarigama harshita.mp3', 2, 'uploads/audios/1575394380Sarigama harshita.mp3', 1, 13526656),
('marete hodenu', '1575394405Marete Hodenu Harshitha.wav', 3, 'uploads/audios/1575394405Marete Hodenu Harshitha.wav', 1, 47305156),
('chithaara', '157539442901 - Chithaara (MyKuttyWeb.com).mp3', 4, 'uploads/audios/157539442901 - Chithaara (MyKuttyWeb.com).mp3', 1, 3657494),
('dishoom', '157539452602 - Toh Dishoom (320 Kbps) - DownloadMi', 5, 'uploads/audios/157539452602 - Toh Dishoom (320 Kbps) - DownloadMing.SE.mp3', 1, 9809912);

-- --------------------------------------------------------

--
-- Table structure for table `docs`
--

CREATE TABLE IF NOT EXISTS `docs` (
  `tag` varchar(20) NOT NULL,
  `docs_name` varchar(40) NOT NULL,
  `docs_id` int(11) NOT NULL AUTO_INCREMENT,
  `docs_location` varchar(250) NOT NULL,
  `user_id` int(3) NOT NULL,
  `docs_size` int(50) NOT NULL,
  PRIMARY KEY (`docs_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `docs`
--

INSERT INTO `docs` (`tag`, `docs_name`, `docs_id`, `docs_location`, `user_id`, `docs_size`) VALUES
('adam', '1571838346adams2013.pdf', 2, 'uploads/docs/1571838346adams2013.pdf', 1, 742632),
('baig', '1575393611baig2015.pdf', 3, 'uploads/docs/1575393611baig2015.pdf', 1, 266490),
('frery', '1575393639frery2015.pdf', 4, 'uploads/docs/1575393639frery2015.pdf', 1, 554316),
('mayda', '1575393659mayda2016.pdf', 5, 'uploads/docs/1575393659mayda2016.pdf', 1, 340301),
('jenkins', '1575393682jenkins2016.pdf', 6, 'uploads/docs/1575393682jenkins2016.pdf', 1, 558854);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `feed_back` varchar(200) NOT NULL,
  `user_id` int(3) NOT NULL,
  `feed_back_id` int(3) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`feed_back_id`),
  UNIQUE KEY `feed_back_id` (`feed_back_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feed_back`, `user_id`, `feed_back_id`) VALUES
('best drive ever\r\n', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `tag` varchar(20) NOT NULL,
  `image_name` varchar(40) NOT NULL,
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `image_location` varchar(250) NOT NULL,
  `user_id` int(3) NOT NULL,
  `image_size` int(50) NOT NULL,
  PRIMARY KEY (`image_id`),
  UNIQUE KEY `image_id` (`image_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`tag`, `image_name`, `image_id`, `image_location`, `user_id`, `image_size`) VALUES
('fb', '1571024047FB_IMG_1483214116803.jpg', 3, 'uploads/images/1571024047FB_IMG_1483214116803.jpg', 1, 131192),
('arc', '1571024089Arc Reactor 01.png', 4, 'uploads/images/1571024089Arc Reactor 01.png', 1, 555872),
('assasin', '157539384075dd828d0b9cbd4adab6c9a652bd9d', 5, 'uploads/images/157539384075dd828d0b9cbd4adab6c9a652bd9dad.png', 1, 588700),
('iron man', '1575393910iron_man_helmet-wallpaper-1280', 6, 'uploads/images/1575393910iron_man_helmet-wallpaper-1280x720.jpg', 1, 180914),
('lion', '1575393930Lion-face-6.jpg', 7, 'uploads/images/1575393930Lion-face-6.jpg', 1, 134522);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`email`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `lname`, `dob`, `email`, `password`) VALUES
(1, 'abc', 'def', '2019-10-02', 'abc@gmail.com', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `tag` varchar(20) NOT NULL,
  `video_name` varchar(50) NOT NULL,
  `video_id` int(11) NOT NULL AUTO_INCREMENT,
  `video_location` varchar(200) NOT NULL,
  `user_id` int(3) NOT NULL,
  `video_size` int(50) NOT NULL,
  PRIMARY KEY (`video_id`),
  UNIQUE KEY `video_id` (`video_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`tag`, `video_name`, `video_id`, `video_location`, `user_id`, `video_size`) VALUES
('cv', '1571806481VID-20180804-WA0011.mp4', 1, 'uploads/videos/1571806481VID-20180804-WA0011.mp4', 1, 5899245),
('swadesh', '1575394159Yun Hi Chala Chal   Swades 2004  HD   Bl', 2, 'uploads/videos/1575394159Yun Hi Chala Chal   Swades 2004  HD   BluRay  Musi.mp4', 1, 48811497),
('alan walker', '1575394186Alan Walker - Alone (Need For Speed).mp4', 3, 'uploads/videos/1575394186Alan Walker - Alone (Need For Speed).mp4', 1, 14098096),
('hack', '1575394223a8OcdNxL_qYpJ5EI.MP4', 4, 'uploads/videos/1575394223a8OcdNxL_qYpJ5EI.MP4', 1, 3876618),
('hack1', '1575394259WeirdLifeHacks_1052258239017115649(MP4).', 5, 'uploads/videos/1575394259WeirdLifeHacks_1052258239017115649(MP4).mp4', 1, 14091110);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
